// // config.js
// export const API_BASE_URL = 'https://appletaxiapi.ktgt.in';
// export const API_IMAGE_URL = 'https://appletaxiapi.ktgt.in/Public/Images';

// config.js
export const API_BASE_URL = 'http://localhost:6037';
export const API_IMAGE_URL = 'http://localhost:6037/Public/Images';